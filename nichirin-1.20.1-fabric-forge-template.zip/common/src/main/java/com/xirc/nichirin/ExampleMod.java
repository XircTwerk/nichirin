package com.xirc.nichirin;

public final class ExampleMod {
    public static final String MOD_ID = "nichirin";

    public static void init() {
        // Write common init code here.
    }
}
